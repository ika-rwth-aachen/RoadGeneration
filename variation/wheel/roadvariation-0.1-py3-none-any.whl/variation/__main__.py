from variation import runner
# main function that runs the whole road network variation
if __name__ == '__main__':
    runner.run()

